﻿using System;
using Google.Cloud.Translation.V2;


    namespace Project_2_Translator
{

    class Program
    {

        static void Main(string[] args)
        {
          
                Console.WriteLine("Hello World! I am a english to german translator.");
                Console.WriteLine(" ");
                Console.WriteLine("Enter an english sentence to translate:");
                string Translate = Console.ReadLine();

                System.Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", "GCP_JSON.json");

                /* string strCmdText = "set GOOGLE_APPLICATION_CREDENTIALS='C:\\Users\\emada\\UC\\10Spring2022-SENIOR\\Cloud_Computing\\Project_2GCP\\GCP_JSON.json'";
                 System.Diagnostics.Process.Start("CMD.exe", strCmdText);
                 Console.WriteLine(strCmdText);*/

                TranslationClient client = TranslationClient.Create();
                TranslationResult result = client.TranslateText(Translate, LanguageCodes.German);
                Console.WriteLine($"Result: {result.TranslatedText}; detected language {result.DetectedSourceLanguage}");
                Console.WriteLine(" ");
                Console.WriteLine("Press any key to close program.");
                Console.ReadKey();
           
        }
    }


}
